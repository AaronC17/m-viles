data class ResearchPaper(
    val title: String = "",
    val description: String = "",
    val topic: String = "",
    val grade: String = "",
    val comments: List<Comment> = emptyList(),
    val imageUrl: String = ""  // Si decides agregar la URL de una imagen
)

data class Comment(
    val comment: String,
    val author: String
)
