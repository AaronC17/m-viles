package com.example.moviles_proyecto

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.moviles_proyecto.databinding.FragmentResearchDetailsBinding
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue

class ResearchDetailsFragment : Fragment() {

    private lateinit var firestore: FirebaseFirestore
    private lateinit var titleTextView: TextView
    private lateinit var descriptionTextView: TextView
    private lateinit var topicTextView: TextView
    private lateinit var gradeTextView: TextView
    private lateinit var commentsTextView: TextView
    private lateinit var commentEditText: EditText
    private lateinit var addCommentButton: Button
    private var researchPaper: ResearchPaper? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentResearchDetailsBinding.inflate(inflater, container, false)

        firestore = FirebaseFirestore.getInstance()

        // Recibir el objeto ResearchPaper desde el bundle
        researchPaper = arguments?.getSerializable("researchPaper") as ResearchPaper?

        titleTextView = binding.titleTextView
        descriptionTextView = binding.descriptionTextView
        gradeTextView = binding.gradeTextView
        topicTextView = binding.topicTextView
        commentsTextView = binding.commentsTextView
        commentEditText = binding.commentEditText
        addCommentButton = binding.addCommentButton

        researchPaper?.let { paper ->
            // Mostrar los detalles del trabajo de investigación
            titleTextView.text = paper.title
            descriptionTextView.text = paper.description
            gradeTextView.text = paper.grade
            topicTextView.text = paper.topic
            commentsTextView.text = paper.comments.joinToString("\n") { it.comment }
        }

        // Agregar un comentario
        addCommentButton.setOnClickListener {
            val commentText = commentEditText.text.toString().trim()
            if (commentText.isNotEmpty()) {
                addComment(commentText)
            } else {
                Toast.makeText(requireContext(), "Por favor, escribe un comentario", Toast.LENGTH_SHORT).show()
            }
        }

        return binding.root
    }

    private fun addComment(commentText: String) {
        researchPaper?.let { paper ->
            val comment = Comment(comment = commentText, author = "User")  // Asume un autor por defecto
            val updatedComments = paper.comments + comment

            firestore.collection("research_papers")
                .document(paper.title)  // Asume que el título es único
                .update("comments", updatedComments)
                .addOnSuccessListener {
                    Toast.makeText(requireContext(), "Comentario agregado", Toast.LENGTH_SHORT).show()
                    // Recargar los comentarios
                    commentsTextView.text = updatedComments.joinToString("\n") { it.comment }
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(), "Error al agregar comentario", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
