package com.example.moviles_proyecto

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.moviles_proyecto.databinding.FragmentResearchListBinding
import com.google.firebase.firestore.FirebaseFirestore

class ResearchListFragment : Fragment() {

    private lateinit var firestore: FirebaseFirestore
    private lateinit var researchRecyclerView: RecyclerView
    private lateinit var researchAdapter: ResearchAdapter
    private var researchPapers: List<ResearchPaper> = listOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentResearchListBinding.inflate(inflater, container, false)

        firestore = FirebaseFirestore.getInstance()
        researchRecyclerView = binding.researchRecyclerView

        // Configurar el RecyclerView
        researchRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        researchAdapter = ResearchAdapter(researchPapers) { researchPaper ->
            // Acción al seleccionar un trabajo de investigación
            openResearchDetails(researchPaper)
        }
        researchRecyclerView.adapter = researchAdapter

        // Cargar los trabajos de investigación
        loadResearchPapers()

        return binding.root
    }

    private fun loadResearchPapers() {
        firestore.collection("research_papers")
            .get()
            .addOnSuccessListener { result ->
                val papers = result.map { document ->
                    ResearchPaper(
                        title = document.getString("title") ?: "",
                        description = document.getString("description") ?: "",
                        topic = document.getString("topic") ?: "",
                        grade = document.getString("grade") ?: "",
                        comments = document.get("comments") as List<Comment>? ?: emptyList(),
                        imageUrl = document.getString("imageUrl") ?: ""
                    )
                }
                researchPapers = papers
                researchAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Error al cargar los trabajos", Toast.LENGTH_SHORT).show()
            }
    }

    private fun openResearchDetails(researchPaper: ResearchPaper) {
        val fragment = ResearchDetailsFragment()
        val bundle = Bundle()
        bundle.putSerializable("researchPaper", researchPaper)
        fragment.arguments = bundle
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }
}
